# MINIMALIST RETAIL MANAGEMENT SYSTEM

This project was made for a mini project in school. Feel free to improve the code quality. Cheers!

## This repository consists of a GUI-based Retail Management System in Python(using tkinter). 

### Pre-Requisites
`Python 3.7`

### Screenshots
![alt text](https://github.com/realmacaw/real-mart/blob/master/images/main.png)
![alt text](https://github.com/realmacaw/real-mart/blob/master/images/employee_login.png)
![alt text](https://github.com/realmacaw/real-mart/blob/master/images/bill_window.png)
![alt text](https://github.com/realmacaw/real-mart/blob/master/images/update_employee.png)


